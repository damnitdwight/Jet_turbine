using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Quitmethod : MonoBehaviour
{
    public void quit(){
        Application.Quit();
    }
}
